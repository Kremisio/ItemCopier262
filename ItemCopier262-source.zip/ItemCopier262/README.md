# Item Copier — Minecraft Java 26.2 / Fabric

Mod client-side: punta il cursore su un oggetto in una schermata d'inventario e premi **Ctrl+C**. La chat mostra il nome dell'oggetto e due pulsanti:

- **COPIA ID**: copia l'ID dell'item, ad esempio `minecraft:player_head`.
- **COPIA DATI / TESTA**: copia la rappresentazione serializzata completa dello stack, inclusi i componenti presenti (per le teste, anche i dati del profilo quando sono salvati sull'oggetto).

## Requisiti
- Minecraft Java 26.2
- Fabric Loader 0.19.5 o compatibile
- Fabric API 0.156.0+26.2
- Java 25 per compilare

## Compilare
Apri la cartella in IntelliJ IDEA come progetto Gradle con JDK 25, poi esegui il task `build`. Il JAR sarà in `build/libs/`.

## Nota
Questa è la prima versione del progetto sorgente e va compilata/testata nel tuo ambiente 26.2: le API Minecraft/Fabric possono richiedere piccoli aggiustamenti se le versioni installate differiscono. Il codice non sposta né modifica l'oggetto.
