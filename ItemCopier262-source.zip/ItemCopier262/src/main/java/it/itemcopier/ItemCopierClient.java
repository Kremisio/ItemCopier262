package it.itemcopier;

import it.itemcopier.mixin.AbstractContainerScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public class ItemCopierClient implements ClientModInitializer {
    private static KeyMapping copyKey;

    @Override
    public void onInitializeClient() {
        copyKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.itemcopier.copy",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "category.itemcopier"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (copyKey.consumeClick()) {
                if (isControlDown(client)) {
                    copyHoveredItem(client);
                }
            }
        });
    }

    private static boolean isControlDown(Minecraft client) {
        long window = client.getWindow().getWindow();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
    }

    private static void copyHoveredItem(Minecraft client) {
        if (!(client.screen instanceof AbstractContainerScreen<?> screen)) {
            return;
        }

        Slot slot = ((AbstractContainerScreenAccessor) screen).itemcopier$getHoveredSlot();
        if (slot == null || !slot.hasItem() || client.player == null || client.level == null) {
            return;
        }

        ItemStack stack = slot.getItem().copy();
        String itemId = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        String fullData = stack.save(client.level.registryAccess()).toString();

        Component title = Component.literal("[Item Copier] ")
                .append(stack.getHoverName())
                .append(Component.literal("  "))
                .append(copyButton("[COPIA ID]", itemId))
                .append(Component.literal("  "))
                .append(copyButton("[COPIA DATI / TESTA]", fullData));

        client.gui.getChat().addMessage(title);
    }

    private static Component copyButton(String label, String value) {
        return Component.literal(label).withStyle(style -> style
                .withColor(0x55FFAA)
                .withUnderlined(true)
                .withClickEvent(new ClickEvent.CopyToClipboard(value))
                .withHoverEvent(new HoverEvent.ShowText(
                        Component.literal("Clicca per copiare negli appunti")
                )));
    }
}
